@echo off
cd /d "%~dp0"

py patch_dao_dlc_packages_local.py ^
  --local-dir "%~dp0DLC" ^
  --metadata-zip "%~dp0patched_dlc_metadata.zip" ^
  --output "%~dp0patched_dlc_packages" ^
  --report "%~dp0patched_dlc_packages_report.json"

if errorlevel 1 (
  echo.
  echo Patchovani skoncilo chybou. Puvodni DLC soubory nebyly zmeneny.
) else (
  echo.
  echo Hotovo. Upravené balicky jsou ve slozce patched_dlc_packages.
)
pause
