#!/usr/bin/env python3
"""Patch Dragon Age: Origins Xbox 360 DLC metadata inside the original STFS packages.

This is for RGH/JTAG consoles. It replaces manifest.xml metadata and redirects the
English CIF title/description fields to Czech text. Packages are copied to an
output directory; originals are never modified.

The script deliberately keeps every file's existing STFS block allocation. That
avoids rebuilding multi-gigabyte DLC packages and only requires recalculating the
hash-tree nodes affected by the changed metadata and file-table blocks.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import struct
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

BLOCK = 0x1000
HASHES_PER_TABLE = 0xAA
L1_SPAN = 0x70E4
L2_SPAN = 0x4AF768
MISSING = 0xFFFFFF

# DAO CIF labels
CIF_NAME_ENUS = 0x42D2
CIF_NAME_CSCZ = 0x42DA
CIF_DESC_ENUS = 0x42DB
CIF_DESC_CSCZ = 0x42E3


def sha1(data: bytes) -> bytes:
    return hashlib.sha1(data).digest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def u24le(data: bytes, off: int) -> int:
    return int.from_bytes(data[off:off + 3], "little")


def physical_index(logical: int) -> int:
    physical = logical + (logical + HASHES_PER_TABLE) // HASHES_PER_TABLE
    if logical >= HASHES_PER_TABLE:
        physical += (logical + L1_SPAN) // L1_SPAN
    if logical >= L1_SPAN:
        physical += (logical + L2_SPAN) // L2_SPAN
    return physical


def l0_physical(group: int) -> int:
    return 0 if group == 0 else physical_index(group * HASHES_PER_TABLE) - 1


def l1_physical(group: int) -> int:
    # Group 0 is inserted before the second L0 table. Later L1 tables are
    # inserted immediately before the L0 table at each 0x70E4 boundary.
    if group == 0:
        return physical_index(HASHES_PER_TABLE) - 2
    return physical_index(group * L1_SPAN) - 2


def l2_physical() -> int:
    return physical_index(L1_SPAN) - 3


@dataclass
class Entry:
    index: int
    name: str
    is_dir: bool
    contiguous: bool
    blocks: int
    start: int
    parent: int
    size: int
    table_logical: int
    table_offset: int


class STFS:
    def __init__(self, path: Path):
        self.path = path
        with path.open("rb") as f:
            self.header = bytearray(f.read(0xB000))
        if self.header[:4] not in (b"PIRS", b"LIVE", b"CON "):
            raise ValueError(f"not an STFS package: magic={bytes(self.header[:4])!r}")
        header_size = int.from_bytes(self.header[0x340:0x344], "big")
        self.base = (header_size + 0xFFF) & ~0xFFF
        if self.base > len(self.header):
            with path.open("rb") as f:
                self.header = bytearray(f.read(self.base))
        self.allocated = int.from_bytes(self.header[0x395:0x399], "big")
        if not (0 < self.allocated < L2_SPAN):
            raise ValueError(f"unsupported allocated block count: {self.allocated}")
        volume = 0x379
        self.table_blocks = int.from_bytes(self.header[volume + 3:volume + 5], "little")
        self.table_start = u24le(self.header, volume + 5)
        if self.table_blocks <= 0:
            raise ValueError("file table has no blocks")
        self.entries: list[Entry] = []
        self._load_table()

    def data_offset(self, logical: int) -> int:
        if not 0 <= logical < self.allocated:
            raise ValueError(f"logical block outside allocation: {logical}")
        return self.base + physical_index(logical) * BLOCK

    def hash_entry_offset(self, logical: int) -> int:
        group, index = divmod(logical, HASHES_PER_TABLE)
        return self.base + l0_physical(group) * BLOCK + index * 0x18

    def next_block(self, logical: int) -> int:
        with self.path.open("rb") as f:
            f.seek(self.hash_entry_offset(logical) + 21)
            return int.from_bytes(f.read(3), "big")

    def chain(self, start: int, count: int, contiguous: bool) -> list[int]:
        if count == 0:
            return []
        if contiguous:
            blocks = list(range(start, start + count))
            if blocks[-1] >= self.allocated:
                raise ValueError("contiguous file extends outside allocation")
            return blocks
        result: list[int] = []
        current = start
        seen: set[int] = set()
        for i in range(count):
            if current in seen or not 0 <= current < self.allocated:
                raise ValueError("invalid/cyclic STFS block chain")
            result.append(current)
            seen.add(current)
            if i + 1 < count:
                current = self.next_block(current)
                if current == MISSING:
                    raise ValueError("STFS chain ended early")
        return result

    def _load_table(self) -> None:
        table_chain = self.chain(self.table_start, self.table_blocks, False)
        # Some packages mark the file table contiguous but still have standard
        # next pointers. If the first chain lookup failed, callers see the error;
        # ordinary DAO packages use valid pointers.
        table = bytearray()
        with self.path.open("rb") as f:
            for logical in table_chain:
                f.seek(self.data_offset(logical))
                table += f.read(BLOCK)
        for off in range(0, len(table), 0x40):
            raw = bytes(table[off:off + 0x40])
            if len(raw) < 0x40 or not any(raw):
                break
            flags = raw[0x28]
            name_len = flags & 0x3F
            if name_len == 0 or name_len > 0x28:
                raise ValueError(f"invalid file-table entry at 0x{off:X}")
            table_block_index, within = divmod(off, BLOCK)
            self.entries.append(Entry(
                index=len(self.entries),
                name=raw[:name_len].decode("ascii"),
                is_dir=bool(flags & 0x80),
                contiguous=bool(flags & 0x40),
                blocks=u24le(raw, 0x29),
                start=u24le(raw, 0x2F),
                parent=int.from_bytes(raw[0x32:0x34], "big", signed=True),
                size=int.from_bytes(raw[0x34:0x38], "big"),
                table_logical=table_chain[table_block_index],
                table_offset=within,
            ))

    def full_path(self, entry: Entry) -> str:
        parts: list[str] = []
        cur = entry
        seen: set[int] = set()
        while True:
            if cur.index in seen:
                raise ValueError("cycle in STFS directory tree")
            seen.add(cur.index)
            parts.append(cur.name)
            if cur.parent < 0:
                break
            if cur.parent >= len(self.entries):
                raise ValueError(f"invalid parent index {cur.parent} for {cur.name}")
            cur = self.entries[cur.parent]
        return "/".join(reversed(parts))

    def files(self) -> dict[str, Entry]:
        return {self.full_path(e): e for e in self.entries if not e.is_dir}

    def read_entry(self, entry: Entry) -> bytes:
        blocks = self.chain(entry.start, entry.blocks, entry.contiguous)
        out = bytearray()
        with self.path.open("rb") as f:
            for logical in blocks:
                f.seek(self.data_offset(logical))
                block = f.read(BLOCK)
                if len(block) != BLOCK:
                    raise ValueError("package ended inside an allocated block")
                out += block
        return bytes(out[:entry.size])

    def write_entry(self, entry: Entry, data: bytes) -> set[int]:
        blocks = self.chain(entry.start, entry.blocks, entry.contiguous)
        capacity = len(blocks) * BLOCK
        if len(data) > capacity:
            raise ValueError(
                f"replacement needs {len(data)} bytes but allocation has {capacity}: {self.full_path(entry)}"
            )
        modified = set(blocks)
        padded = data.ljust(capacity, b"\0")
        with self.path.open("r+b") as f:
            for i, logical in enumerate(blocks):
                f.seek(self.data_offset(logical))
                f.write(padded[i * BLOCK:(i + 1) * BLOCK])
            # Update only the file-size field; block allocation and chain remain unchanged.
            f.seek(self.data_offset(entry.table_logical) + entry.table_offset + 0x34)
            f.write(len(data).to_bytes(4, "big"))
        entry.size = len(data)
        modified.add(entry.table_logical)
        return modified

    def update_hash_tree(self, modified_logical: set[int]) -> None:
        modified_l0: set[int] = set()
        with self.path.open("r+b") as f:
            for logical in sorted(modified_logical):
                f.seek(self.data_offset(logical))
                data = f.read(BLOCK)
                if len(data) != BLOCK:
                    raise ValueError("short block while hashing")
                f.seek(self.hash_entry_offset(logical))
                f.write(sha1(data))
                modified_l0.add(logical // HASHES_PER_TABLE)

            modified_l1: set[int] = set()
            for group in sorted(modified_l0):
                f.seek(self.base + l0_physical(group) * BLOCK)
                table = f.read(BLOCK)
                parent_group, parent_index = divmod(group, HASHES_PER_TABLE)
                if self.allocated <= HASHES_PER_TABLE:
                    self.header[0x381:0x395] = sha1(table)
                else:
                    f.seek(self.base + l1_physical(parent_group) * BLOCK + parent_index * 0x18)
                    f.write(sha1(table))
                    modified_l1.add(parent_group)

            if self.allocated > HASHES_PER_TABLE:
                if self.allocated <= L1_SPAN:
                    # One L1 table is the top table.
                    f.seek(self.base + l1_physical(0) * BLOCK)
                    self.header[0x381:0x395] = sha1(f.read(BLOCK))
                else:
                    for group in sorted(modified_l1):
                        f.seek(self.base + l1_physical(group) * BLOCK)
                        table = f.read(BLOCK)
                        f.seek(self.base + l2_physical() * BLOCK + group * 0x18)
                        f.write(sha1(table))
                    f.seek(self.base + l2_physical() * BLOCK)
                    self.header[0x381:0x395] = sha1(f.read(BLOCK))

            # Header hash covers the metadata area from 0x344 through base offset.
            self.header[0x32C:0x340] = sha1(bytes(self.header[0x344:self.base]))
            f.seek(0)
            f.write(self.header[:self.base])

    def verify_modified_hashes(self, modified_logical: set[int]) -> None:
        with self.path.open("rb") as f:
            for logical in modified_logical:
                f.seek(self.data_offset(logical))
                data = f.read(BLOCK)
                f.seek(self.hash_entry_offset(logical))
                if f.read(20) != sha1(data):
                    raise AssertionError(f"L0 hash mismatch after patch: block {logical}")
            f.seek(0x32C)
            header_hash = f.read(20)
            f.seek(0x344)
            header_tail = f.read(self.base - 0x344)
            if header_hash != sha1(header_tail):
                raise AssertionError("header hash mismatch after patch")
            if self.allocated <= HASHES_PER_TABLE:
                f.seek(self.base + l0_physical(0) * BLOCK)
                top = sha1(f.read(BLOCK))
            elif self.allocated <= L1_SPAN:
                f.seek(self.base + l1_physical(0) * BLOCK)
                top = sha1(f.read(BLOCK))
            else:
                f.seek(self.base + l2_physical() * BLOCK)
                top = sha1(f.read(BLOCK))
            f.seek(0x381)
            if f.read(20) != top:
                raise AssertionError("top hash mismatch after patch")


def cif_fields(data: bytes) -> tuple[int, dict[int, int]]:
    if len(data) < 44 or data[:20] != b"GFF V4.0X360CIF V0.1":
        raise ValueError(f"unsupported CIF header: {data[:20]!r}")
    struct_count = struct.unpack_from(">I", data, 20)[0]
    data_offset = struct.unpack_from(">I", data, 24)[0]
    if struct_count < 1 or data_offset >= len(data):
        raise ValueError("invalid CIF header")
    _label, field_count, field_offset, _size = struct.unpack_from(">IIII", data, 28)
    fields: dict[int, int] = {}
    for i in range(field_count):
        pos = field_offset + i * 12
        label, type_flags, relative = struct.unpack_from(">III", data, pos)
        if (type_flags & 0xFFFF) == 0x000E:
            fields[label] = data_offset + relative
    return data_offset, fields


def cif_ref(data: bytes, fields: dict[int, int], label: int) -> int:
    pos = fields.get(label)
    if pos is None:
        raise ValueError(f"CIF field missing: 0x{label:04X}")
    return struct.unpack_from(">I", data, pos)[0]


def cif_read_ref(data: bytes, data_offset: int, ref: int) -> str:
    if ref == 0xFFFFFFFF:
        return ""
    pos = data_offset + ref
    if pos + 4 > len(data):
        raise ValueError("CIF string pointer outside file")
    units = struct.unpack_from(">I", data, pos)[0]
    end = pos + 4 + units * 2
    if end > len(data):
        raise ValueError("CIF string outside file")
    value = data[pos + 4:end].decode("utf-16be")
    return value[:-1] if value.endswith("\0") else value


def cif_read(data: bytes, label: int) -> str:
    base, fields = cif_fields(data)
    return cif_read_ref(data, base, cif_ref(data, fields, label))


def string_object(text: str) -> bytes:
    encoded = text.encode("utf-16be") + b"\0\0"
    raw = struct.pack(">I", len(encoded) // 2) + encoded
    return raw + b"\0" * ((-len(raw)) % 4)


def existing_object_span(data: bytes, data_offset: int, ref: int) -> tuple[int, int]:
    pos = data_offset + ref
    units = struct.unpack_from(">I", data, pos)[0]
    raw_len = 4 + units * 2
    return pos, raw_len + ((-raw_len) % 4)


def patch_cif_compact(original: bytes, target: bytes, capacity: int) -> bytes:
    """Create target EN metadata without exceeding the original block allocation."""
    desired_title = cif_read(target, CIF_NAME_ENUS)
    desired_desc = cif_read(target, CIF_DESC_ENUS)
    data_offset, fields = cif_fields(original)
    buf = bytearray(original.ljust(capacity, b"\0"))
    used_end = len(original)
    reserved: set[int] = set()

    def put(label_en: int, label_cs: int, desired: str) -> None:
        nonlocal used_end
        en_ptr_pos = fields[label_en]
        candidate_labels = [label_cs, label_en]

        # Reuse any existing Czech/English object already containing the desired text.
        for label in candidate_labels:
            ref = cif_ref(bytes(buf), fields, label)
            if ref != 0xFFFFFFFF and cif_read_ref(bytes(buf), data_offset, ref) == desired:
                struct.pack_into(">I", buf, en_ptr_pos, ref)
                return

        obj = string_object(desired)
        # Prefer overwriting the Czech slot, then the English slot, when it fits.
        for label in candidate_labels:
            ref = cif_ref(bytes(buf), fields, label)
            if ref == 0xFFFFFFFF or ref in reserved:
                continue
            pos, span = existing_object_span(bytes(buf), data_offset, ref)
            if len(obj) <= span:
                buf[pos:pos + span] = obj.ljust(span, b"\0")
                reserved.add(ref)
                struct.pack_into(">I", buf, en_ptr_pos, ref)
                return

        # Append into already allocated slack; this changes only the logical file size.
        pos = (used_end + 3) & ~3
        end = pos + len(obj)
        if end > capacity:
            raise ValueError(f"CIF translation does not fit allocation: need {end}, capacity {capacity}")
        buf[pos:end] = obj
        ref = pos - data_offset
        struct.pack_into(">I", buf, en_ptr_pos, ref)
        used_end = end

    put(CIF_NAME_ENUS, CIF_NAME_CSCZ, desired_title)
    put(CIF_DESC_ENUS, CIF_DESC_CSCZ, desired_desc)
    result_size = max(len(original), used_end)
    result = bytes(buf[:result_size])
    if cif_read(result, CIF_NAME_ENUS) != desired_title:
        raise AssertionError("CIF title round-trip failed")
    if cif_read(result, CIF_DESC_ENUS) != desired_desc:
        raise AssertionError("CIF description round-trip failed")
    return result


def load_metadata_zip(path: Path) -> dict[str, bytes]:
    result: dict[str, bytes] = {}
    with zipfile.ZipFile(path) as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            name = PurePosixPath(info.filename).as_posix()
            if not (name.endswith("/manifest.xml") or name.casefold().endswith(".cif")):
                continue
            result[name] = z.read(info)
    if not result:
        raise ValueError(f"metadata ZIP contains no manifest.xml/CIF files: {path}")
    return result


def candidate_files(root: Path, output: Path) -> list[Path]:
    result: list[Path] = []
    output_resolved = output.resolve()
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        try:
            path.resolve().relative_to(output_resolved)
            continue
        except ValueError:
            pass
        result.append(path)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--local-dir", type=Path, required=True, help="Folder containing original DAO DLC STFS packages")
    parser.add_argument("--metadata-zip", type=Path, default=Path(__file__).with_name("patched_dlc_metadata.zip"))
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("patched_dlc_packages"))
    parser.add_argument("--report", type=Path, default=Path(__file__).with_name("patched_dlc_packages_report.json"))
    args = parser.parse_args()

    source_root = args.local_dir.resolve()
    output_root = args.output.resolve()
    if not source_root.is_dir():
        parser.error(f"--local-dir is not a directory: {source_root}")
    metadata = load_metadata_zip(args.metadata_zip)
    output_root.mkdir(parents=True, exist_ok=True)

    report: dict[str, object] = {
        "source": str(source_root),
        "output": str(output_root),
        "metadata_zip": str(args.metadata_zip.resolve()),
        "packages": [],
        "skipped": [],
        "errors": [],
    }
    patched_count = 0

    for source in candidate_files(source_root, output_root):
        rel = source.relative_to(source_root)
        try:
            with source.open("rb") as probe_file:
                magic = probe_file.read(4)
            if magic not in (b"PIRS", b"LIVE", b"CON "):
                report["skipped"].append({"path": str(rel), "reason": "not an STFS package"})
                continue
            probe = STFS(source)
            package_files = probe.files()
            matches = sorted(set(package_files) & set(metadata), key=str.casefold)
            if not matches:
                report["skipped"].append({"path": str(rel), "reason": "no matching metadata"})
                continue

            target = output_root / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            print(f"COPY  {rel} ({source.stat().st_size:,} bytes)", flush=True)
            shutil.copy2(source, target)
            stfs = STFS(target)
            files = stfs.files()
            modified: set[int] = set()
            changes: list[dict[str, object]] = []

            for internal in matches:
                entry = files[internal]
                original = stfs.read_entry(entry)
                capacity = entry.blocks * BLOCK
                if internal.casefold().endswith(".cif"):
                    replacement = patch_cif_compact(original, metadata[internal], capacity)
                else:
                    replacement = metadata[internal]
                modified |= stfs.write_entry(entry, replacement)
                changes.append({
                    "path": internal,
                    "old_size": len(original),
                    "new_size": len(replacement),
                    "capacity": capacity,
                    "title": cif_read(replacement, CIF_NAME_ENUS) if internal.casefold().endswith(".cif") else None,
                })
                print(f"PATCH {internal}: {len(original)} -> {len(replacement)} / {capacity}", flush=True)

            stfs.update_hash_tree(modified)
            stfs.verify_modified_hashes(modified)
            # Reopen and verify payload round-trip.
            check = STFS(target)
            check_files = check.files()
            for change in changes:
                internal = str(change["path"])
                data = check.read_entry(check_files[internal])
                if internal.casefold().endswith(".cif"):
                    desired_title = cif_read(metadata[internal], CIF_NAME_ENUS)
                    desired_desc = cif_read(metadata[internal], CIF_DESC_ENUS)
                    if cif_read(data, CIF_NAME_ENUS) != desired_title or cif_read(data, CIF_DESC_ENUS) != desired_desc:
                        raise AssertionError(f"CIF verification failed: {internal}")
                elif data != metadata[internal]:
                    raise AssertionError(f"manifest verification failed: {internal}")

            item = {
                "source": str(rel),
                "output": str(target.relative_to(output_root)),
                "magic": magic.decode("ascii", "replace"),
                "size": target.stat().st_size,
                "sha256": sha256_file(target),
                "changes": changes,
                "validation": "PASS",
            }
            report["packages"].append(item)
            patched_count += 1
            print(f"OK    {rel} sha256={item['sha256']}", flush=True)
        except Exception as exc:
            report["errors"].append({"path": str(rel), "error": f"{type(exc).__name__}: {exc}"})
            print(f"ERROR {rel}: {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)

    report["patched_packages"] = patched_count
    report["metadata_entries"] = len(metadata)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"\nDone: patched={patched_count} errors={len(report['errors'])}")
    print(f"Output: {output_root}")
    print(f"Report: {args.report.resolve()}")
    return 0 if patched_count and not report["errors"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
