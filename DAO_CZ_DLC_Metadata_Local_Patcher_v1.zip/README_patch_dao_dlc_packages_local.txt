Dragon Age: Origins Xbox 360 – lokální oprava názvů a popisů DLC
================================================================

Proč je to potřeba
------------------
TLK soubory lze překrýt Title Updatem, ale názvy kampaní a metadata obrazovky
„Obsah ke stažení“ hra čte přímo z manifest.xml a *.cif uvnitř původních DLC
STFS balíčků. Proto TU #15 tuto poslední část nezměnil.

Požadavky
---------
- Xbox 360 RGH/JTAG se zapnutým načítáním upraveného/odemčeného obsahu.
- Lokální složka DLC obsahující celé původní soubory z:
  Hdd1/Content/0000000000000000/454108C0/00000002
- Python 3.10 nebo novější.

Příprava
--------
Do jedné složky dejte:
- patch_dao_dlc_packages_local.py
- run_patch_dao_dlc_packages_local.bat
- patched_dlc_metadata.zip

Celé původní DLC balíčky vložte do podsložky:
DLC

Spuštění
--------
Spusťte run_patch_dao_dlc_packages_local.bat

Nebo ručně:
py patch_dao_dlc_packages_local.py --local-dir DLC --metadata-zip patched_dlc_metadata.zip --output patched_dlc_packages --report patched_dlc_packages_report.json

Výsledek
--------
Upravené balíčky se stejnými názvy vzniknou ve složce patched_dlc_packages.
Původní soubory ve složce DLC se nemění.

Instalace
---------
1. Zálohujte původní DLC soubory na Xboxu.
2. Nahraďte jen soubory, které skript vytvořil ve patched_dlc_packages.
3. Zachovejte stejné názvy a stejnou cílovou cestu 00000002.
4. Konzoli úplně restartujte.
5. Ověřte nabídku Nová hra a Obsah ke stažení.

TU #14 nebo #15 může zůstat nainstalovaný; pro překlad dialogů a DLC TLK je stále
potřeba. Metadata vložená navíc do TU #15 jsou neškodná, ale sama se nepoužijí.

Bezpečnost
----------
Skript nemění originály. Přepisujte Xbox až po kontrole, že report uvádí u všech
upravených balíčků validation: PASS. Modifikace zneplatní původní podpis STFS;
na běžné retail konzoli proto upravené balíčky nefungují.
